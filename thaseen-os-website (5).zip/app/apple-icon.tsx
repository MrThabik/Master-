import { ImageResponse } from "next/og";
import { getSettings } from "@/lib/settings";

// The small picture shown in browser tabs, bookmarks and Google results (favicon).
// Uses your profile photo link from Developer Space > SEO Kit if set, otherwise a gold "TS" monogram.
export const size = { width: 180, height: 180 };
export const contentType = "image/png";
export const revalidate = 3600;

export default async function Icon() {
  const s = await getSettings();
  return new ImageResponse(
    s.seo_image ? (
      <div style={{ width: "100%", height: "100%", display: "flex", background: "#060807" }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={s.seo_image} width={180} height={180} style={{ objectFit: "cover", width: "100%", height: "100%" }} alt="" />
      </div>
    ) : (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,#060807,#0b1a14)", color: "#d4af37", fontSize: 100, fontWeight: 700, border: "6px solid #d4af37", borderRadius: 0 }}>
        TS
      </div>
    ),
    size
  );
}
