import type { Metadata } from "next";
import Link from "next/link";
import { getSettings, siteBase } from "@/lib/settings";
import { getVisibleSites, profileLinks } from "@/lib/seo";

export const revalidate = 30;

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return { title: { absolute: s.about_title }, description: s.about_body.replace(/\s+/g, " ").slice(0, 155), alternates: { canonical: "/about" } };
}

export default async function About() {
  const s = await getSettings();
  const base = siteBase();
  const sites = await getVisibleSites();
  const ld = {
    "@context": "https://schema.org", "@type": "ProfilePage", url: `${base}/about`,
    mainEntity: { "@type": "Person", "@id": `${base}/#person`, name: s.owner_name, jobTitle: s.job_title, description: s.about_body.replace(/\s+/g, " ").slice(0, 300), ...(s.seo_image ? { image: s.seo_image } : {}), sameAs: profileLinks(s, sites) },
  };
  return (
    <main className="mx-auto min-h-screen max-w-2xl px-5 py-12 leading-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, "\\u003c") }} />
      <Link href="/" className="text-sm text-em">← {s.site_name}</Link>
      <p className="mt-6 text-xs uppercase tracking-[.35em] text-gold">{s.tagline}</p>
      <h1 className="my-2 font-serif text-4xl text-gold">{s.about_title}</h1>
      <p className="mb-6 text-muted">{s.job_title}</p>
      {s.about_body.split(/\n\s*\n/).map((p, i) => <p key={i} className="mb-4 whitespace-pre-line">{p}</p>)}
      <h2 className="mb-2 mt-8 font-serif text-2xl text-gold">My websites</h2>
      <ul className="grid gap-3">
        {sites.map((x) => (
          <li key={x.id}>
            <a className="text-em underline" href={x.url} rel="noopener">{x.name}</a>
            <span className="text-muted"> – {x.url.replace(/^https?:\/\//, "")}</span>
            {x.description && <p className="text-sm text-muted">{x.description}</p>}
          </li>
        ))}
      </ul>
    </main>
  );
}
