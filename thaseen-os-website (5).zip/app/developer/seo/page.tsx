"use client";
import { useEffect, useState } from "react";
import { supabase, Site } from "@/lib/supabase";
import Gate from "@/components/Gate";
import SaveBar from "@/components/SaveBar";
import { useSettings } from "@/hooks/useSettings";
import { cleanUrl, siteFooterSnippet, siteHeadSnippet } from "@/lib/seo";
import { list } from "@/lib/settings";

const inp = "w-full rounded-lg border bd-gold-30 bg-field p-2.5 text-base text-fg sm:text-sm";
const chip = "bd-gold-40 rounded-full border px-4 py-2 text-sm text-gold";
const HUB = (process.env.NEXT_PUBLIC_SITE_URL ?? "").replace(/\/$/, "");

function Box({ title, children, wide }: { title: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <section className={`bd-gold-25 grid content-start gap-3 rounded-xl border p-4 ${wide ? "xl:col-span-2" : ""}`}>
      <h2 className="font-serif text-2xl text-gold">{title}</h2>
      {children}
    </section>
  );
}

function Editor() {
  const { v, set, save, dirty, msg } = useSettings();
  const [sites, setSites] = useState<Site[]>([]);
  const [note, setNote] = useState("");
  const [open, setOpen] = useState<string>("");

  useEffect(() => {
    supabase.from("sites").select("*").eq("hidden", false).order("sort").then(({ data }) => setSites((data as Site[]) ?? []));
  }, []);

  const hubOk = HUB.startsWith("https://") && !HUB.includes("example.com") && !HUB.includes("yourdomain");
  const links = Array.from(new Set([...list(v.same_as), ...sites.map((x) => x.url)].map(cleanUrl).filter((u) => u && u !== HUB)));
  const nameInTitle = /thaseen\s+shabik/i.test(v.seo_title);
  const dl = v.seo_description.length;
  const thin = sites.filter((x) => (x.description ?? "").trim().length < 60);
  const noShot = sites.filter((x) => !x.screenshot_url);
  const checks: { ok: boolean; text: string; tip: string }[] = [
    { ok: hubOk, text: "Main address is set", tip: "In Vercel > Settings > Environment Variables, set NEXT_PUBLIC_SITE_URL to your main address (https://...), then redeploy." },
    { ok: nameInTitle, text: "Google title contains \"Thaseen Shabik\"", tip: "Edit the Google title in Site Settings & SEO so it starts with your full name." },
    { ok: dl >= 70 && dl <= 160, text: `Google description length is good (${dl} characters, aim for 70 to 160)`, tip: "Rewrite the description in Site Settings & SEO." },
    { ok: list(v.also_known_as).length >= 1, text: "Other spellings of your name are listed", tip: "Add spellings people may type, for example Thaseen Shabik, Thasheen Shabik." },
    { ok: links.length >= 5, text: `Profile and website links listed (${links.length} found, aim for 5 or more)`, tip: "Press \"Add my websites to the profile links\" below, and add your social profiles." },
    { ok: !!v.seo_image, text: "Profile photo link is set", tip: "Paste a public link to a clear photo of you below (a Supabase Storage public link works)." },
    { ok: sites.length > 0 && thin.length === 0, text: `Every website has a description of 60+ characters${thin.length ? ` (${thin.length} need one)` : ""}`, tip: "Write a clear description for each website in the Websites page." },
    { ok: sites.length > 0 && noShot.length === 0, text: `Every website has a screenshot${noShot.length ? ` (${noShot.length} missing)` : ""}`, tip: "Capture or upload screenshots in the Websites page." },
  ];
  const score = checks.filter((c) => c.ok).length;

  const merge = () => {
    set("same_as", links.join("\n") as never);
    setNote(`Added. ${links.length} links will be used. Press Save changes.`);
  };
  const copy = async (text: string, label: string) => {
    try { await navigator.clipboard.writeText(text); setNote(`Copied: ${label}`); }
    catch { window.prompt("Copy this text:", text); }
  };

  return (
    <div>
      <h1 className="font-serif text-3xl text-gold">SEO Kit</h1>
      <p className="mt-1 text-sm text-muted">Helps Google, Bing and AI search connect all your websites to the name <b>{v.owner_name}</b>.</p>

      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Box title={`Health check: ${score} of ${checks.length}`} wide>
          <ul className="grid gap-2">
            {checks.map((c) => (
              <li key={c.text} className="bd-gold-25 rounded-lg border p-3 text-sm">
                <span className={c.ok ? "text-em" : "text-gold"}>{c.ok ? "✓ " : "✗ "}{c.text}</span>
                {!c.ok && <p className="mt-1 text-xs text-muted">{c.tip}</p>}
              </li>
            ))}
          </ul>
          <p className="text-xs text-muted">Nobody can guarantee a Google ranking. This checks that everything you control is set up correctly.</p>
        </Box>

        <Box title="Profile photo and links">
          <label className="grid gap-1 text-sm text-muted">
            <span>Profile photo link (public https link, also used when your site is shared)</span>
            <input className={inp} value={v.seo_image} onChange={(e) => set("seo_image", e.target.value)} placeholder="https://..." autoCapitalize="none" spellCheck={false} />
          </label>
          <label className="grid gap-1 text-sm text-muted">
            <span>Profile and website links (one per line)</span>
            <textarea className={`${inp} min-h-[150px]`} value={v.same_as} onChange={(e) => set("same_as", e.target.value)} autoCapitalize="none" spellCheck={false} />
          </label>
          <button className={`${chip} w-fit`} onClick={merge}>Add my websites to the profile links</button>
          <p className="text-xs text-muted">Your websites from the Websites page are added to Google automatically. Add Instagram, YouTube, LinkedIn and GitHub links here too.</p>
        </Box>

        <Box title="Submit to search engines">
          <p className="text-sm text-muted">Your sitemap lists the hub, About, Gallery, Blog and every website on your own domain.</p>
          <input className={inp} readOnly value={hubOk ? `${HUB}/sitemap.xml` : "Set NEXT_PUBLIC_SITE_URL first"} />
          <div className="flex flex-wrap gap-2">
            <button className={chip} onClick={() => hubOk && copy(`${HUB}/sitemap.xml`, "sitemap address")}>Copy sitemap address</button>
            <a className={chip} href="https://search.google.com/search-console" target="_blank" rel="noopener">Google Search Console ↗</a>
            <a className={chip} href="https://www.bing.com/webmasters" target="_blank" rel="noopener">Bing Webmaster ↗</a>
            {hubOk && <a className={chip} href={`https://search.google.com/test/rich-results?url=${encodeURIComponent(HUB)}`} target="_blank" rel="noopener">Test structured data ↗</a>}
          </div>
          <p className="text-xs text-muted">In Search Console: Sitemaps, paste <code>sitemap.xml</code>, Submit. Then URL Inspection, paste your main address, Request indexing.</p>
        </Box>

        <Box title="SEO code for your other websites" wide>
          <p className="text-sm text-muted">Your other websites are separate projects, so they need this code once. It gives each one a name-rich title, a description, a canonical address and a link of authorship back to you. Open a website below, copy the <b>head code</b> into its <code>&lt;head&gt;</code> and the <b>footer link</b> into its footer, then redeploy it.</p>
          {sites.map((x) => {
            const head = siteHeadSnippet(x, v, HUB || "https://yourdomain.com");
            const foot = siteFooterSnippet(v, HUB || "https://yourdomain.com");
            const on = open === x.id;
            return (
              <div key={x.id} className="bd-gold-25 rounded-lg border p-3">
                <button className="flex w-full items-center justify-between text-left text-base text-fg" onClick={() => setOpen(on ? "" : x.id)}>
                  <span>{x.name}<span className="block text-xs text-muted">{x.url}</span></span>
                  <span className="text-gold">{on ? "−" : "+"}</span>
                </button>
                {on && (
                  <div className="mt-3 grid gap-3">
                    <label className="grid gap-1 text-xs text-muted">Head code
                      <textarea readOnly className={`${inp} min-h-[170px] font-mono text-xs`} value={head} />
                    </label>
                    <button className={`${chip} w-fit`} onClick={() => copy(head, `${x.name} head code`)}>Copy head code</button>
                    <label className="grid gap-1 text-xs text-muted">Footer link
                      <textarea readOnly className={`${inp} min-h-[60px] font-mono text-xs`} value={foot} />
                    </label>
                    <button className={`${chip} w-fit`} onClick={() => copy(foot, `${x.name} footer link`)}>Copy footer link</button>
                    {(x.description ?? "").trim().length < 60 && <p className="text-xs text-gold">This website's description is short. Improve it in the Websites page first, then copy the code again.</p>}
                  </div>
                )}
              </div>
            );
          })}
          {!sites.length && <p className="text-sm text-muted">Add websites in the Websites page first.</p>}
        </Box>
      </div>
      <p className="mt-4 text-em">{note}</p>
      <SaveBar dirty={dirty} msg={msg} onSave={save} />
    </div>
  );
}

export default function Page() { return <Gate><Editor /></Gate>; }
