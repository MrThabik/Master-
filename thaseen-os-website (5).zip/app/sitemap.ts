import type { MetadataRoute } from "next";
import { supabase } from "@/lib/supabase";
import { getVisibleSites, cleanUrl, onSameDomain } from "@/lib/seo";

export const revalidate = 3600;
const base = (process.env.NEXT_PUBLIC_SITE_URL ?? "https://example.com").replace(/\/$/, "");

// Served at /sitemap.xml. Blog posts and your other websites are added automatically.
// Websites on your own domain (for example mrthabik21.thaseenshabik.in) are listed too,
// which works because one Search Console "Domain" property covers all subdomains.
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const { data } = await supabase.from("posts").select("slug,created_at").eq("published", true);
  let changed = new Date();
  try {
    const { data: st } = await supabase.from("settings").select("updated_at").eq("id", 1).single();
    if (st?.updated_at) changed = new Date(st.updated_at);
  } catch { /* keep today's date */ }
  const sites = await getVisibleSites();
  const siteUrls = Array.from(new Set(sites.map((x) => cleanUrl(x.url)).filter((u) => u && u !== base && onSameDomain(u, base))));
  return [
    { url: base, lastModified: changed, changeFrequency: "weekly", priority: 1 },
    { url: `${base}/about`, lastModified: changed, changeFrequency: "monthly", priority: 0.9 },
    ...siteUrls.map((u) => ({ url: u, lastModified: changed, changeFrequency: "monthly" as const, priority: 0.8 })),
    { url: `${base}/gallery`, lastModified: changed, changeFrequency: "weekly", priority: 0.8 },
    { url: `${base}/moodboard`, lastModified: changed, changeFrequency: "weekly", priority: 0.7 },
    { url: `${base}/blog`, lastModified: changed, changeFrequency: "weekly", priority: 0.8 },
    ...(data ?? []).map((p) => ({
      url: `${base}/blog/${p.slug}`,
      lastModified: new Date(p.created_at),
      changeFrequency: "monthly" as const,
      priority: 0.6,
    })),
  ];
}
