import { supabase, type Site } from "@/lib/supabase";
import { list, siteBase, type Settings } from "@/lib/settings";

// Public (not hidden) websites shown on the hub
export async function getVisibleSites(): Promise<Site[]> {
  try {
    const { data } = await supabase.from("sites").select("*").eq("hidden", false).order("sort");
    return (data as Site[] | null) ?? [];
  } catch {
    return [];
  }
}

// "https://a.b.in/" -> "https://a.b.in"; invalid links -> ""
export const cleanUrl = (u: string) => {
  try {
    const x = new URL(u.trim());
    if (x.protocol !== "https:" && x.protocol !== "http:") return "";
    return x.origin + (x.pathname === "/" ? "" : x.pathname.replace(/\/$/, ""));
  } catch {
    return "";
  }
};

// Profile links = the list typed in Developer Space + every website on the hub (no duplicates, never the hub itself)
export function profileLinks(s: Settings, sites: { url: string }[]): string[] {
  const base = siteBase();
  const out = new Set<string>();
  for (const u of [...list(s.same_as), ...sites.map((x) => x.url)]) {
    const c = cleanUrl(u);
    if (c && c !== base) out.add(c);
  }
  return Array.from(out);
}

// thaseenshabik.in for both thaseenshabik.in and masterweb2.thaseenshabik.in
export function parentHost(base: string): string {
  try {
    const parts = new URL(base).hostname.split(".");
    return parts.length > 2 ? parts.slice(1).join(".") : parts.join(".");
  } catch {
    return "";
  }
}
export function onSameDomain(url: string, base: string): boolean {
  try {
    const h = new URL(url).hostname;
    const p = parentHost(base);
    return !!p && (h === p || h.endsWith("." + p));
  } catch {
    return false;
  }
}

export function personLd(s: Settings, base: string, links: string[]) {
  const names = Array.from(new Set([s.owner_name, ...list(s.also_known_as)]));
  return {
    "@context": "https://schema.org", "@type": "Person", "@id": `${base}/#person`,
    name: s.owner_name, alternateName: names, jobTitle: s.job_title, description: s.seo_description,
    url: base, mainEntityOfPage: `${base}/about`,
    image: s.seo_image ? s.seo_image : undefined,
    sameAs: links,
    knowsAbout: ["Electrical and Electronics Engineering", "FANUC robot programming", "VMC machining", "Renewable energy systems", "Photography", "Digital art"],
  };
}

const esc = (x: string) => x.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// Copy-and-paste SEO code for one of the OTHER websites (they are separate projects)
export function siteHeadSnippet(site: { name: string; url: string; description: string }, s: Settings, hub: string): string {
  const url = cleanUrl(site.url) || site.url;
  const title = `${s.owner_name} – ${site.name}`;
  const desc = (site.description || s.seo_description).replace(/\s+/g, " ").trim().slice(0, 160);
  const ld = {
    "@context": "https://schema.org", "@type": "WebSite", "@id": `${url}/#website`,
    name: site.name, url, description: desc, inLanguage: "en",
    author: { "@type": "Person", "@id": `${hub}/#person`, name: s.owner_name, url: hub },
  };
  return [
    `<title>${esc(title)}</title>`,
    `<meta name="description" content="${esc(desc)}">`,
    `<link rel="canonical" href="${esc(url)}">`,
    `<meta name="author" content="${esc(s.owner_name)}">`,
    `<meta property="og:type" content="website">`,
    `<meta property="og:title" content="${esc(title)}">`,
    `<meta property="og:description" content="${esc(desc)}">`,
    `<meta property="og:url" content="${esc(url)}">`,
    `<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, "\\u003c")}</script>`,
  ].join("\n");
}

export const siteFooterSnippet = (s: Settings, hub: string) =>
  `<a href="${esc(hub)}" rel="me">${esc(s.owner_name)} – official website</a>`;
